from pathlib import Path
import zipfile, struct, hashlib, zlib, shutil, subprocess, os, json

BASE = Path('/mnt/data/base.apk')
OUTDIR = Path('/mnt/data/maimemo-toolbox-build')
OUTDIR.mkdir(exist_ok=True)
ORIGINAL_HTML_PATH = OUTDIR / 'speedmeter-original-v3.html'
NEW_HTML_PATH = OUTDIR / 'maimemo-toolbox.html'
PATCHED_DEX_PATH = OUTDIR / 'classes.dex'
UNSIGNED_APK = Path('/mnt/data/maimemo-toolbox-v4-unsigned.apk')
SIGNED_APK = Path('/mnt/data/maimemo-toolbox-v4.apk')
KEYSTORE = Path('/mnt/data/maimemo-toolbox-release.keystore')

# --- DEX helpers ---
def read_uleb(data, pos):
    value = 0
    shift = 0
    start = pos
    while True:
        b = data[pos]
        pos += 1
        value |= (b & 0x7f) << shift
        if b < 0x80:
            return value, pos, data[start:pos]
        shift += 7
        if shift > 35:
            raise ValueError('bad uleb128')

def enc_uleb(value):
    if value < 0:
        raise ValueError('negative uleb')
    out = bytearray()
    while True:
        b = value & 0x7f
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)

def u32(data, off): return struct.unpack_from('<I', data, off)[0]
def put32(data, off, value): struct.pack_into('<I', data, off, value)

def get_strings(dex):
    count, off = u32(dex, 56), u32(dex, 60)
    out=[]
    for i in range(count):
        so=u32(dex, off+4*i)
        utf16_len,p,_=read_uleb(dex,so)
        end=dex.index(b'\0',p)
        raw=dex[p:end]
        out.append((so,utf16_len,p,end,raw.decode('utf-8')))
    return out

def map_entries(dex):
    mo=u32(dex,52); count=u32(dex,mo)
    entries=[]
    for i in range(count):
        typ,unused,size,off=struct.unpack_from('<HHII',dex,mo+4+12*i)
        entries.append((typ,size,off,mo+4+12*i))
    return entries

def add_css(html):
    css = r'''
/* Added tool selector and converter; existing speed-meter styles are kept intact. */
.home-shell,.calc-shell{max-width:820px;margin:0 auto;padding:24px 18px 36px}
.home-hero{padding:20px 4px 24px}.home-title{font-size:30px;font-weight:850;letter-spacing:-.7px}.home-subtitle{color:#9aa4b2;margin-top:8px;line-height:1.6}
.feature-card{width:100%;display:flex;align-items:center;gap:14px;text-align:left;background:#171a21;color:#f5f7fb;border:1px solid #2a2f3a;border-radius:20px;padding:18px;margin:12px 0;min-height:92px;cursor:pointer}
.feature-icon{width:52px;height:52px;border-radius:15px;display:flex;align-items:center;justify-content:center;background:#252c3a;font-size:25px;flex-shrink:0}
.feature-copy{flex:1}.feature-copy strong{display:block;font-size:18px}.feature-copy small{display:block;color:#9aa4b2;font-size:13px;margin-top:5px;font-weight:400}.feature-arrow{font-size:25px;color:#9aa4b2}
.tool-nav{max-width:820px;margin:0 auto;padding:10px 18px 0}.tool-nav button{background:#282e3a;color:#fff;min-height:40px;padding:0 14px;border-radius:11px}
.calc-shell{padding-top:8px}.tool-tabs{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0 14px}.tool-tab{background:#202631;color:#aeb8c8;border:1px solid #303744}.tool-tab.active{background:#7aa2ff;color:#07101f}
.calc-input{font-size:30px!important;font-weight:750;text-align:right;min-height:64px;margin:0 0 12px!important}
.calc-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.calc-grid button{min-width:0;padding:0;min-height:54px;background:#242a35;color:#f5f7fb;border:1px solid #333b49;font-size:20px}.calc-grid button.op{background:#303e58;color:#c5d7ff}.calc-grid button.eq{background:#7aa2ff;color:#07101f}.calc-grid button.clear{background:#492328;color:#ffd9dd}
.convert-field{margin:12px 0}.convert-field input,.convert-field select,.angle-grid input,.angle-grid select{width:100%;background:#10131a;color:#fff;border:1px solid #303744;border-radius:12px;padding:13px;font-size:16px;margin-top:7px;min-height:48px}
.convert-row{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);gap:8px;align-items:end}.convert-row button{background:#282e3a;color:#fff;min-width:48px;padding:0 12px}
.convert-result{font-size:25px;font-weight:800;overflow-wrap:anywhere;background:#10131a;border:1px solid #303744;border-radius:14px;padding:16px;margin-top:12px;color:#9fc0ff}
.angle-box{margin-top:16px;padding-top:16px;border-top:1px solid #303744}.angle-box h3{font-size:17px;margin:0 0 8px}.angle-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.angle-grid .sign-cell{grid-column:span 3}.angle-output{background:#10131a;border-radius:12px;padding:12px;margin-top:10px;overflow-wrap:anywhere;color:#c5d7ff}
.small-help{color:#9aa4b2;font-size:13px;line-height:1.55;margin-top:8px}
@media(max-width:480px){.home-title{font-size:26px}.feature-card{padding:14px}.convert-row{grid-template-columns:minmax(0,1fr) 42px minmax(0,1fr)}.angle-grid{gap:6px}.angle-grid input,.angle-grid select{padding:10px;font-size:15px}}
'''
    return html.replace('</style>', css + '</style>', 1)

HOME = r'''<div id="homePage" class="page" style="display:block">
<div class="home-shell">
  <div class="home-hero"><div class="home-title">墨墨工具箱</div><div class="home-subtitle">背词计速、计算与单位换算</div></div>
  <button type="button" class="feature-card" onclick="showPage('speedPage')"><span class="feature-icon">📖</span><span class="feature-copy"><strong>背词速度计</strong><small>本轮平均、今日平均与学习时长</small></span><span class="feature-arrow">›</span></button>
  <button type="button" class="feature-card" onclick="showPage('calcPage')"><span class="feature-icon">＋</span><span class="feature-copy"><strong>计算器与单位换算</strong><small>基础四则运算、角度数字互转及常见单位</small></span><span class="feature-arrow">›</span></button>
  <div class="small-help">选择一个功能开始使用。背词速度计原有的计速逻辑与数据请求保持不变。</div>
</div>
</div>
<div id="speedPage" class="page" style="display:none">
<div class="tool-nav"><button type="button" onclick="showPage('homePage')">← 功能首页</button></div>
'''

CALC_PAGE = r'''<div id="calcPage" class="page" style="display:none">
<div class="tool-nav"><button type="button" onclick="showPage('homePage')">← 功能首页</button></div>
<div class="calc-shell">
  <div class="tool-tabs"><button id="tabCalculator" class="tool-tab active" type="button">计算器</button><button id="tabConverter" class="tool-tab" type="button">单位换算</button></div>
  <section id="calculatorPanel" class="card">
    <input id="calcInput" class="calc-input" value="0" readonly aria-label="计算表达式">
    <div class="calc-grid">
      <button class="clear" data-key="AC">AC</button><button data-key="DEL">⌫</button><button class="op" data-key="%">%</button><button class="op" data-key="÷">÷</button>
      <button data-key="7">7</button><button data-key="8">8</button><button data-key="9">9</button><button class="op" data-key="×">×</button>
      <button data-key="4">4</button><button data-key="5">5</button><button data-key="6">6</button><button class="op" data-key="−">−</button>
      <button data-key="1">1</button><button data-key="2">2</button><button data-key="3">3</button><button class="op" data-key="+">+</button>
      <button data-key="(">(</button><button data-key="0">0</button><button data-key=".">.</button><button data-key=")">)</button>
      <button data-key="SIGN">±</button><button class="clear" data-key="AC">清空</button><button class="eq" data-key="=" style="grid-column:span 2">=</button>
    </div>
    <div id="calcStatus" class="small-help">支持加、减、乘、除、括号和百分比。</div>
  </section>
  <section id="converterPanel" class="card" style="display:none">
    <div class="convert-field"><label for="unitCategory">换算类别</label><select id="unitCategory"></select></div>
    <div class="convert-field"><label for="unitValue">输入数值</label><input id="unitValue" type="number" inputmode="decimal" value="1" step="any"></div>
    <div class="convert-row">
      <div class="convert-field"><label for="unitFrom">从</label><select id="unitFrom"></select></div>
      <button type="button" id="swapUnits" aria-label="交换单位">⇄</button>
      <div class="convert-field"><label for="unitTo">换算为</label><select id="unitTo"></select></div>
    </div>
    <div class="muted">换算结果</div><div id="unitResult" class="convert-result">1</div>
    <div class="small-help">支持角度、长度、质量、面积、体积、温度、时间、速度、数据存储、压力、能量和功率。</div>
    <div class="angle-box">
      <h3>角度数字互转：十进制度 ↔ 度分秒</h3>
      <div class="convert-field"><label for="decimalDeg">十进制度（°）</label><input id="decimalDeg" type="number" inputmode="decimal" step="any" value="12.504167"></div>
      <button id="toDms" class="primary" type="button">十进制度 → 度分秒</button>
      <div id="dmsOutput" class="angle-output">12° 30′ 15.00″</div>
      <div class="angle-grid">
        <div class="sign-cell"><label for="dmsSign">角度正负</label><select id="dmsSign"><option value="1">正角度（+）</option><option value="-1">负角度（−）</option></select></div>
        <div><label for="dmsD">度</label><input id="dmsD" type="number" inputmode="decimal" min="0" value="12"></div>
        <div><label for="dmsM">分（0–59）</label><input id="dmsM" type="number" inputmode="decimal" min="0" max="59" value="30"></div>
        <div><label for="dmsS">秒（0–59.999）</label><input id="dmsS" type="number" inputmode="decimal" min="0" max="59.999999" step="any" value="15"></div>
      </div>
      <button id="fromDms" class="primary" type="button" style="margin-top:12px;width:100%">度分秒 → 十进制度</button>
      <div id="dmsDecimalOutput" class="angle-output">12.5041666667°</div>
      <div class="small-help">例如 12° 30′ 15″ = 12.5041667°。角度单位换算也可在上方“角度”类别中进行。</div>
    </div>
  </section>
</div>
</div>
'''

EXTRA_SCRIPT = r'''<script>
(function(){
  window.showPage=function(id){['homePage','speedPage','calcPage'].forEach(function(x){var e=document.getElementById(x);if(e)e.style.display=x===id?'block':'none';});window.scrollTo(0,0);};
  var calcInput=document.getElementById('calcInput'),calcStatus=document.getElementById('calcStatus');
  function evaluate(expr){
    var s=String(expr).replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/\s+/g,'');
    var i=0;
    function peek(){return s[i]||'';}
    function eat(c){if(peek()===c){i++;return true;}return false;}
    function number(){var start=i,dot=false;while(i<s.length){var c=s[i];if(c>='0'&&c<='9'){i++;continue;}if(c==='.'&&!dot){dot=true;i++;continue;}break;}if(start===i)throw Error('数字格式不正确');var n=Number(s.slice(start,i));if(!Number.isFinite(n))throw Error('数字无效');return n;}
    function primary(){if(eat('(')){var v=add();if(!eat(')'))throw Error('缺少右括号');return v;}return number();}
    function unary(){if(eat('+'))return unary();if(eat('-'))return -unary();var v=primary();while(eat('%'))v/=100;return v;}
    function mul(){var v=unary();while(true){if(eat('*'))v*=unary();else if(eat('/')){var r=unary();if(r===0)throw Error('不能除以 0');v/=r;}else break;}return v;}
    function add(){var v=mul();while(true){if(eat('+'))v+=mul();else if(eat('-'))v-=mul();else break;}return v;}
    if(!s)throw Error('请输入算式');var result=add();if(i!==s.length)throw Error('算式格式不正确');if(!Number.isFinite(result))throw Error('结果超出范围');return result;
  }
  function fmt(n){if(!Number.isFinite(n))return '—';if(Math.abs(n)<1e-12)n=0;return Number(n.toPrecision(12)).toString();}
  document.querySelectorAll('.calc-grid button').forEach(function(b){b.addEventListener('click',function(){var k=b.getAttribute('data-key'),s=calcInput.value;if(k==='AC'){calcInput.value='0';calcStatus.textContent='已清空。';return;}if(k==='DEL'){calcInput.value=s.length>1?s.slice(0,-1):'0';return;}if(k==='='){try{calcInput.value=fmt(evaluate(s));calcStatus.textContent='计算完成。';}catch(e){calcStatus.textContent=e.message||'算式错误';}return;}if(k==='SIGN'){if(s==='0')return;calcInput.value=s.startsWith('-')?s.slice(1):'-('+s+')';return;}calcInput.value=s==='0'&&!'+−-×÷%.)'.includes(k)?k:s+k;calcStatus.textContent='';});});
  var categories={
    angle:{label:'角度',units:[['十进制度（°）',1],['弧度（rad）',180/Math.PI],['百分度（grad）',0.9],['角分（′）',1/60],['角秒（″）',1/3600]]},
    length:{label:'长度',units:[['米（m）',1],['千米（km）',1000],['厘米（cm）',0.01],['毫米（mm）',0.001],['微米（μm）',0.000001],['英寸（in）',0.0254],['英尺（ft）',0.3048],['英里（mi）',1609.344]]},
    mass:{label:'质量',units:[['千克（kg）',1000],['克（g）',1],['毫克（mg）',0.001],['吨（t）',1000000],['磅（lb）',453.59237],['盎司（oz）',28.349523125]]},
    area:{label:'面积',units:[['平方米（m²）',1],['平方千米（km²）',1000000],['平方厘米（cm²）',0.0001],['公顷（ha）',10000],['英亩（acre）',4046.8564224],['平方英尺（ft²）',0.09290304]]},
    volume:{label:'体积',units:[['升（L）',1],['毫升（mL）',0.001],['立方米（m³）',1000],['立方厘米（cm³）',0.001],['美制加仑（US gal）',3.785411784],['杯（US cup）',0.2365882365]]},
    temperature:{label:'温度',units:[['摄氏度（°C）',1],['华氏度（°F）',1],['开尔文（K）',1]]},
    time:{label:'时间',units:[['秒（s）',1],['毫秒（ms）',0.001],['分钟（min）',60],['小时（h）',3600],['天（d）',86400],['周（week）',604800]]},
    speed:{label:'速度',units:[['米/秒（m/s）',1],['千米/小时（km/h）',1000/3600],['英里/小时（mph）',0.44704],['节（kn）',0.5144444444]]},
    data:{label:'数据存储',units:[['字节（B）',1],['KB（1000 B）',1000],['MB（1000 KB）',1000000],['GB（1000 MB）',1000000000],['KiB（1024 B）',1024],['MiB（1024 KiB）',1048576],['GiB（1024 MiB）',1073741824]]},
    pressure:{label:'压力',units:[['帕（Pa）',1],['千帕（kPa）',1000],['兆帕（MPa）',1000000],['巴（bar）',100000],['标准大气压（atm）',101325],['磅/平方英寸（psi）',6894.757293]]},
    energy:{label:'能量',units:[['焦耳（J）',1],['千焦（kJ）',1000],['卡（cal）',4.184],['千卡（kcal）',4184],['瓦时（Wh）',3600],['千瓦时（kWh）',3600000],['电子伏（eV）',1.602176634e-19]]},
    power:{label:'功率',units:[['瓦（W）',1],['千瓦（kW）',1000],['兆瓦（MW）',1000000],['公制马力（PS）',735.49875],['英制马力（hp）',745.699872]]}
  };
  var cat=document.getElementById('unitCategory'),from=document.getElementById('unitFrom'),to=document.getElementById('unitTo'),value=document.getElementById('unitValue'),result=document.getElementById('unitResult');
  Object.keys(categories).forEach(function(k){var o=document.createElement('option');o.value=k;o.textContent=categories[k].label;cat.appendChild(o);});
  function fillUnits(){var u=categories[cat.value].units;[from,to].forEach(function(sel){sel.innerHTML='';u.forEach(function(x){var o=document.createElement('option');o.value=x[0];o.textContent=x[0];sel.appendChild(o);});});if(u.length>1)to.selectedIndex=1;convert();}
  function tempToC(v,u){if(u.indexOf('华氏')===0)return (v-32)*5/9;if(u.indexOf('开尔文')===0)return v-273.15;return v;}
  function cToTemp(v,u){if(u.indexOf('华氏')===0)return v*9/5+32;if(u.indexOf('开尔文')===0)return v+273.15;return v;}
  function convert(){var n=Number(value.value);if(value.value.trim()===''||!Number.isFinite(n)){result.textContent='请输入有效数值';return;}var us=categories[cat.value].units,a=us.find(function(x){return x[0]===from.value;}),b=us.find(function(x){return x[0]===to.value;});if(!a||!b)return;var v=cat.value==='temperature'?cToTemp(tempToC(n,a[0]),b[0]):n*a[1]/b[1];result.textContent=fmt(v)+' '+b[0];}
  cat.addEventListener('change',fillUnits);from.addEventListener('change',convert);to.addEventListener('change',convert);value.addEventListener('input',convert);document.getElementById('swapUnits').addEventListener('click',function(){var x=from.value;from.value=to.value;to.value=x;convert();});fillUnits();
  var dec=document.getElementById('decimalDeg'),dmsOut=document.getElementById('dmsOutput'),dmsD=document.getElementById('dmsD'),dmsM=document.getElementById('dmsM'),dmsS=document.getElementById('dmsS'),dmsSign=document.getElementById('dmsSign'),dmsDecOut=document.getElementById('dmsDecimalOutput');
  function toDMS(){var v=Number(dec.value);if(dec.value.trim()===''||!Number.isFinite(v)){dmsOut.textContent='请输入有效角度';return;}var sign=v<0?'−':'',a=Math.abs(v),d=Math.floor(a),mfull=(a-d)*60,m=Math.floor(mfull),s=(mfull-m)*60;if(s>=59.9999995){s=0;m++;}if(m>=60){m=0;d++;}dmsOut.textContent=sign+d+'° '+m+'′ '+s.toFixed(2)+'″';dmsD.value=d;dmsM.value=m;dmsS.value=s.toFixed(2);dmsSign.value=v<0?'-1':'1';dmsDecOut.textContent=fmt(v)+'°';}
  function fromDMS(){var d=Number(dmsD.value),m=Number(dmsM.value),s=Number(dmsS.value);if([d,m,s].some(function(x){return !Number.isFinite(x)||x<0;})||m>=60||s>=60){dmsDecOut.textContent='请检查输入：度应为非负数，分和秒需在 0–59 之间。';return;}var v=Number(dmsSign.value)*(d+m/60+s/3600);dec.value=fmt(v);dmsDecOut.textContent=fmt(v)+'°';}
  document.getElementById('toDms').addEventListener('click',toDMS);document.getElementById('fromDms').addEventListener('click',fromDMS);toDMS();
  document.getElementById('tabCalculator').addEventListener('click',function(){document.getElementById('calculatorPanel').style.display='block';document.getElementById('converterPanel').style.display='none';this.classList.add('active');document.getElementById('tabConverter').classList.remove('active');});
  document.getElementById('tabConverter').addEventListener('click',function(){document.getElementById('calculatorPanel').style.display='none';document.getElementById('converterPanel').style.display='block';this.classList.add('active');document.getElementById('tabCalculator').classList.remove('active');});
})();
</script>
'''

def patch_axml_string_pool(axml, index, replacement):
    b=bytearray(axml)
    pos=8
    while pos < len(b):
        typ, hsize, size=struct.unpack_from('<HHI',b,pos)
        if typ==0x0001:
            count=struct.unpack_from('<I',b,pos+8)[0]
            flags=struct.unpack_from('<I',b,pos+16)[0]
            strings_start=struct.unpack_from('<I',b,pos+20)[0]
            if index>=count or not (flags & 0x100):
                raise RuntimeError('AXML string pool format unexpected')
            rel=struct.unpack_from('<I',b,pos+28+4*index)[0]
            p=pos+strings_start+rel
            def read_len8(buf, q):
                x=buf[q]; q+=1
                if x&0x80:
                    n=((x&0x7f)<<8)|buf[q]; q+=1
                else: n=x
                return n,q
            _,p=read_len8(b,p)
            old_len,p=read_len8(b,p)
            rep=replacement.encode('utf-8')
            if len(rep)!=old_len:
                raise RuntimeError('AXML replacement must preserve byte length: '+replacement)
            b[p:p+old_len]=rep
            return bytes(b)
        pos+=size
    raise RuntimeError('AXML string pool not found')

def patch_manifest(manifest):
    # Same byte lengths preserve every string-pool offset.
    m=bytearray(patch_axml_string_pool(manifest,4,'com.openai.wordmeter.v4'))
    m=bytearray(patch_axml_string_pool(m,6,'4'))
    m=bytearray(patch_axml_string_pool(m,8,'4.0'))
    m=bytearray(patch_axml_string_pool(m,17,'墨墨工具箱'))
    # Find the root <manifest> start-element and change the typed versionCode value to 4.
    pos=8
    while pos < len(m):
        typ,hsize,size=struct.unpack_from('<HHI',m,pos)
        if typ==0x0102:
            name_idx=struct.unpack_from('<I',m,pos+20)[0]
            # String index 2 is "manifest" in the provided APK's string pool.
            if name_idx==2:
                attr_start=struct.unpack_from('<H',m,pos+24)[0]
                attr_size=struct.unpack_from('<H',m,pos+26)[0]
                attr_count=struct.unpack_from('<H',m,pos+28)[0]
                ap=pos+16+attr_start
                for i in range(attr_count):
                    a=ap+i*attr_size
                    attr_name=struct.unpack_from('<I',m,a+4)[0]
                    if attr_name==5: # "versionCode"
                        struct.pack_into('<I',m,a+16,4)
                        return bytes(m)
                raise RuntimeError('versionCode attribute not found')
        pos+=size
    raise RuntimeError('manifest root element not found')

# Read base APK and extract dex.
with zipfile.ZipFile(BASE, 'r') as z:
    names=z.namelist()
    dex=z.read('classes.dex')
    manifest=patch_manifest(z.read('AndroidManifest.xml'))

strings=get_strings(dex)
html_index=max(range(len(strings)),key=lambda i:len(strings[i][4]))
old_off,old_utf16,old_data_pos,old_null,html=strings[html_index]
if html_index != 0 or not html.startswith('<!doctype html>') or 'sessionSpeed' not in html or 'daySpeed' not in html:
    raise RuntimeError('上传的 APK 结构与预期 v3 不符，停止修改以避免破坏原功能。')
ORIGINAL_HTML_PATH.write_text(html,encoding='utf-8')

# Add new pages around, but do not edit the original speed-meter main markup or script.
html2=add_css(html)
needle='</head><body><main>'
if html2.count(needle)!=1:
    raise RuntimeError('未找到唯一的原页面入口。')
html2=html2.replace(needle,'</head><body>'+HOME+'<main>',1)
needle='</main><script>'
if html2.count(needle)!=1:
    raise RuntimeError('未找到唯一的原 main/script 边界。')
html2=html2.replace(needle,'</main></div>'+CALC_PAGE+EXTRA_SCRIPT+'<script>',1)
NEW_HTML_PATH.write_text(html2,encoding='utf-8')

# DEX replace: replace first HTML string item in place and shift later data by delta.
old_item_start=old_off
old_item_end=old_null+1
old_item_size=old_item_end-old_item_start
html_bytes=html2.encode('utf-8')
utf16_len=len(html2.encode('utf-16-le'))//2
new_item=enc_uleb(utf16_len)+html_bytes+b'\0'
delta1=len(new_item)-old_item_size
newdex=bytearray(dex[:old_item_start]+new_item+dex[old_item_end:])

# Header offsets and sizes after the first insertion.
put32(newdex,32,len(newdex))
put32(newdex,52,u32(dex,52)+(delta1 if u32(dex,52)>=old_item_end else 0))
put32(newdex,104,u32(dex,104)+delta1)

# Shift all string_data offsets whose targets were after the replaced item.
string_ids_size=u32(dex,56); string_ids_off=u32(dex,60)
for i in range(string_ids_size):
    old_target=u32(dex,string_ids_off+4*i)
    if old_target>=old_item_end:
        put32(newdex,string_ids_off+4*i,old_target+delta1)

# Shift proto_ids parameters_off fields.
proto_size,proto_off=u32(dex,72),u32(dex,76)
for i in range(proto_size):
    field=proto_off+i*12+8
    old_target=u32(dex,field)
    if old_target>=old_item_end:
        put32(newdex,field,old_target+delta1)

# Shift absolute offsets in class_def_item.
class_size,class_off=u32(dex,96),u32(dex,100)
for i in range(class_size):
    base=class_off+i*32
    for rel in (12,20,24,28):
        old_target=u32(dex,base+rel)
        if old_target not in (0,0xffffffff) and old_target>=old_item_end:
            put32(newdex,base+rel,old_target+delta1)

# Shift map entries (the map list itself moved too).
new_map_off=u32(newdex,52)
map_count=u32(newdex,new_map_off)
for i in range(map_count):
    ep=new_map_off+4+12*i
    old_type,unused,size,old_target=struct.unpack_from('<HHII',dex,u32(dex,52)+4+12*i)
    if old_target>=old_item_end:
        put32(newdex,ep+8,old_target+delta1)

# Parse class_data to find method code offsets. Their encoded values need to shift.
class_data_off=u32(newdex,class_off+24)
if class_data_off==0:
    raise RuntimeError('class_data_off 缺失。')
def parse_class_data(buf, off):
    p=off; raw_counts=[]; counts=[]
    for _ in range(4):
        v,p,raw=read_uleb(buf,p); counts.append(v); raw_counts.append(raw)
    out=bytearray(b''.join(raw_counts))
    for _ in range(counts[0]+counts[1]):
        for __ in range(2):
            _,p,raw=read_uleb(buf,p); out.extend(raw)
    codeoffs=[]
    for methods_count in (counts[2],counts[3]):
        for _ in range(methods_count):
            for __ in range(2):
                _,p,raw=read_uleb(buf,p); out.extend(raw)
            code_pos=p
            code,p,raw=read_uleb(buf,p)
            codeoffs.append((code_pos,code,raw))
            out.extend(raw)
    return bytes(out),p,codeoffs
old_class_data,old_cd_end,codeoffs=parse_class_data(newdex,class_data_off)

# Patch code-item debug_info_off if nonzero and pointing after the inserted HTML.
for code_pos,old_code_off,raw in codeoffs:
    if old_code_off==0: continue
    new_code_off=old_code_off+(delta1 if old_code_off>=old_item_end else 0)
    if new_code_off+12>len(newdex):
        raise RuntimeError('code item offset 越界。')
    debug_off=u32(newdex,new_code_off+8)
    if debug_off>=old_item_end:
        put32(newdex,new_code_off+8,debug_off+delta1)

# Rebuild class_data with adjusted code_off ULEB128 values.
class_data_new=bytearray()
p=class_data_off
counts=[]
for _ in range(4):
    v,p,raw=read_uleb(newdex,p); counts.append(v); class_data_new.extend(raw)
for _ in range(counts[0]+counts[1]):
    for __ in range(2):
        _,p,raw=read_uleb(newdex,p); class_data_new.extend(raw)
for methods_count in (counts[2],counts[3]):
    for _ in range(methods_count):
        for __ in range(2):
            _,p,raw=read_uleb(newdex,p); class_data_new.extend(raw)
        code,p,raw=read_uleb(newdex,p)
        shifted=code+(delta1 if code>=old_item_end else 0)
        class_data_new.extend(enc_uleb(shifted))
class_data_end=p
class_data_old_len=class_data_end-class_data_off
delta2=len(class_data_new)-class_data_old_len
if delta2:
    map_off_before=u32(newdex,52)
    newdex=bytearray(newdex[:class_data_off]+class_data_new+newdex[class_data_end:])
    put32(newdex,32,len(newdex))
    put32(newdex,52,map_off_before+delta2)
    put32(newdex,104,u32(newdex,104)+delta2)
    mapoff=u32(newdex,52)
    for i in range(u32(newdex,mapoff)):
        ep=mapoff+4+12*i
        target=u32(newdex,ep+8)
        if target>=map_off_before:
            put32(newdex,ep+8,target+delta2)

# Give the toolbox its own package name so it can coexist with the old v3 app.
# The replacement is same-length, so string-data offsets remain unchanged.
updated_strings=get_strings(bytes(newdex))
found_descriptor=False
for item in updated_strings:
    if item[4]=='Lcom/openai/wordmeter/v3/MainActivity;':
        replacement='Lcom/openai/wordmeter/v4/MainActivity;'.encode('utf-8')
        if len(replacement)!=(item[3]-item[2]):
            raise RuntimeError('Activity descriptor replacement length mismatch')
        newdex[item[2]:item[3]]=replacement
        found_descriptor=True
        break
if not found_descriptor:
    raise RuntimeError('Could not find MainActivity descriptor')

# Update dex signature and checksum.
newdex[12:32]=hashlib.sha1(newdex[32:]).digest()
put32(newdex,8,zlib.adler32(newdex[12:]) & 0xffffffff)
PATCHED_DEX_PATH.write_bytes(newdex)

# Sanity checks: decode all string ids, check offsets and map ordering.
verify=get_strings(bytes(newdex))
if verify[html_index][4] != html2:
    raise RuntimeError('写入后的 HTML 校验不一致。')
for i,(off,utf16_len,p0,end,s) in enumerate(verify):
    if not (0 <= off < len(newdex)):
        raise RuntimeError('字符串偏移越界：'+str(i))
if u32(newdex,32)!=len(newdex):
    raise RuntimeError('DEX file_size 校验失败。')
if newdex[12:32] != hashlib.sha1(newdex[32:]).digest():
    raise RuntimeError('DEX SHA-1 校验失败。')
if u32(newdex,8) != (zlib.adler32(newdex[12:]) & 0xffffffff):
    raise RuntimeError('DEX Adler32 校验失败。')

# Build unsigned APK, removing old signatures before signing with a fresh local key.
with zipfile.ZipFile(BASE,'r') as zin, zipfile.ZipFile(UNSIGNED_APK,'w',zipfile.ZIP_DEFLATED) as zout:
    for info in zin.infolist():
        name=info.filename
        if name=='classes.dex':
            zout.writestr(name,bytes(newdex))
        elif name=='AndroidManifest.xml':
            zout.writestr(name,manifest)
        elif name.upper().startswith('META-INF/') and name.upper().endswith(('.SF','.RSA','.DSA','.EC')):
            continue
        elif name.upper()=='META-INF/MANIFEST.MF':
            continue
        else:
            zout.writestr(info,zin.read(name))

if KEYSTORE.exists(): KEYSTORE.unlink()
subprocess.run(['keytool','-genkeypair','-keystore',str(KEYSTORE),'-storepass','meter-local-2026','-keypass','meter-local-2026','-alias','wordmeter','-dname','CN=Wordmeter Toolbox, OU=Personal, O=Wordmeter, L=NA, ST=NA, C=US','-keyalg','RSA','-keysize','2048','-validity','10000','-noprompt'],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
if SIGNED_APK.exists(): SIGNED_APK.unlink()
subprocess.run(['jarsigner','-keystore',str(KEYSTORE),'-storepass','meter-local-2026','-keypass','meter-local-2026','-sigalg','SHA256withRSA','-digestalg','SHA-256','-signedjar',str(SIGNED_APK),str(UNSIGNED_APK),'wordmeter'],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
subprocess.run(['jarsigner','-verify',str(SIGNED_APK)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
with zipfile.ZipFile(SIGNED_APK,'r') as z:
    bad=z.testzip()
    if bad: raise RuntimeError('APK ZIP 检查失败：'+bad)
    if 'classes.dex' not in z.namelist(): raise RuntimeError('APK 缺少 classes.dex')

# Make source bundle (without keystore or tokens).
readme='''墨墨工具箱 v4（基于用户提供的背词速度计 v3 APK）\n\n功能：\n- 首页：背词速度计、计算器与单位换算。\n- 原背词速度计的原始主界面与原始脚本保持不变，仅放在“背词速度计”入口下。\n- 基础四则运算、括号、百分比。\n- 单位换算：角度、长度、质量、面积、体积、温度、时间、速度、数据存储、压力、能量、功率。\n- 角度十进制度与度分秒互转。\n\n构建产物：maimemo-toolbox-v4.apk\n源码文件：maimemo-toolbox.html、build_toolbox.py\n\n注意：新版使用独立包名 com.openai.wordmeter.v4，可与旧版并存，不需要卸载旧版。新旧 App 的本地数据互不共享，因此新版需要重新输入墨墨 API Token。APK 使用本次生成的新签名，且未在用户实际设备上进行安装测试。\n'''
(OUTDIR/'README.txt').write_text(readme,encoding='utf-8')
shutil.copy(__file__,OUTDIR/'build_toolbox.py')
source_zip=Path('/mnt/data/maimemo-toolbox-v4-source.zip')
if source_zip.exists():source_zip.unlink()
with zipfile.ZipFile(source_zip,'w',zipfile.ZIP_DEFLATED) as z:
    for p in [NEW_HTML_PATH,ORIGINAL_HTML_PATH,OUTDIR/'build_toolbox.py',OUTDIR/'README.txt']:
        z.write(p,p.name)
print(json.dumps({
 'apk':str(SIGNED_APK),'apk_size':SIGNED_APK.stat().st_size,
 'source_zip':str(source_zip),'source_zip_size':source_zip.stat().st_size,
 'html_old_bytes':len(html.encode()),'html_new_bytes':len(html2.encode()),'delta1':delta1,'delta2':delta2,
 'dex_old_size':len(dex),'dex_new_size':len(newdex),'string_count':len(verify),
 'sha1':newdex[12:32].hex(),'checksum':hex(u32(newdex,8))
},ensure_ascii=False,indent=2))

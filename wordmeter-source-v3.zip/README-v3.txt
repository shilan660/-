背词速度计 v3

修复：兼容墨墨 get_study_progress 返回值中 progress/data/progress 等嵌套结构，不再假定 finished 位于顶层。
兼容两个已见的学习进度接口路径：
1) /open/api/v1/study/get_study_progress
2) /open/api/v1/memo/study/get_study_progress（仅在 404/405 时回退）

今日平均速度 = finished / (study_time / 60000)
study_time 单位为毫秒。

说明：本 v3 使用独立应用包名 com.openai.wordmeter.v3，可与之前测试版并存；验证工作正常后可手动卸载旧版。

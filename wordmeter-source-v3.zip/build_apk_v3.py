import struct, hashlib, zlib, zipfile, os, subprocess, textwrap, html as htmlmod
from pathlib import Path

OUTDIR=Path('/mnt/data/wordmeter_build')
PKG='com.openai.wordmeter.v3'
MAIN_DESC='Lcom/openai/wordmeter/v3/MainActivity;'

# ---------------- AXML (binary AndroidManifest.xml) ----------------
NO_INDEX=0xffffffff
RES_STRING_POOL_TYPE=0x0001
RES_XML_TYPE=0x0003
RES_XML_RESOURCE_MAP_TYPE=0x0180
RES_XML_START_NAMESPACE_TYPE=0x0100
RES_XML_END_NAMESPACE_TYPE=0x0101
RES_XML_START_ELEMENT_TYPE=0x0102
RES_XML_END_ELEMENT_TYPE=0x0103
UTF8_FLAG=0x00000100
TYPE_STRING=0x03
TYPE_INT_DEC=0x10


def u8_len(n):
    if n < 0x80: return bytes([n])
    return bytes([(n >> 8) | 0x80, n & 0xff])

def utf16_len(s):
    return len(s.encode('utf-16-le'))//2

def string_pool(strings):
    offsets=[]; blob=bytearray()
    for s in strings:
        offsets.append(len(blob))
        b=s.encode('utf-8')
        blob += u8_len(utf16_len(s)) + u8_len(len(b)) + b + b'\x00'
    while len(blob)%4: blob.append(0)
    header_size=28
    strings_start=header_size+4*len(strings)
    size=strings_start+len(blob)
    out=bytearray(struct.pack('<HHI', RES_STRING_POOL_TYPE, header_size, size))
    out += struct.pack('<IIIII', len(strings),0,UTF8_FLAG,strings_start,0)
    out += b''.join(struct.pack('<I',x) for x in offsets)
    out += blob
    return bytes(out)

def axml_node_header(typ, size, line=1):
    return struct.pack('<HHIII', typ, 16, size, line, NO_INDEX)

def ns_chunk(typ,prefix_idx,uri_idx,line):
    return axml_node_header(typ,24,line)+struct.pack('<II',prefix_idx,uri_idx)

def typed_value(data_type,data):
    return struct.pack('<HBBI',8,0,data_type,data)

def start_element(name_idx, attrs, line, ns=NO_INDEX):
    # attrs: list of (ns_idx,name_idx,raw_idx,type,data)
    ext=struct.pack('<IIHHHHHH', ns,name_idx,20,20,len(attrs),0,0,0)
    ab=bytearray()
    for ans,aname,raw,t,d in attrs:
        ab += struct.pack('<III',ans,aname,raw)
        ab += typed_value(t,d)
    size=16+len(ext)+len(ab)
    return axml_node_header(RES_XML_START_ELEMENT_TYPE,size,line)+ext+ab

def end_element(name_idx,line,ns=NO_INDEX):
    return axml_node_header(RES_XML_END_ELEMENT_TYPE,24,line)+struct.pack('<II',ns,name_idx)

def build_manifest():
    # Keep resource-backed Android attrs to a minimal known set.
    strings=[
        'android','http://schemas.android.com/apk/res/android',
        'manifest','package',PKG,'versionCode','3','versionName','3.0',
        'uses-sdk','targetSdkVersion','28',
        'uses-permission','name','android.permission.INTERNET',
        'application','label','背词速度计',
        'activity','.MainActivity','intent-filter','action','android.intent.action.MAIN',
        'category','android.intent.category.LAUNCHER'
    ]
    idx={s:i for i,s in enumerate(strings)}
    android_uri=idx['http://schemas.android.com/apk/res/android']
    # Resource IDs for Android framework attributes.
    # android:name = 0x01010003; android:label = 0x01010001; targetSdkVersion = 0x01010270
    res_ids=[0]*len(strings)
    res_ids[idx['name']]=0x01010003
    res_ids[idx['label']]=0x01010001
    res_ids[idx['targetSdkVersion']]=0x01010270
    res_ids[idx['versionCode']]=0x0101021b
    res_ids[idx['versionName']]=0x0101021c
    resmap=struct.pack('<HHI',RES_XML_RESOURCE_MAP_TYPE,8,8+4*len(res_ids))+b''.join(struct.pack('<I',x) for x in res_ids)

    chunks=[]; line=1
    chunks.append(ns_chunk(RES_XML_START_NAMESPACE_TYPE,idx['android'],android_uri,line)); line+=1
    chunks.append(start_element(idx['manifest'],[(NO_INDEX,idx['package'],idx[PKG],TYPE_STRING,idx[PKG]),(android_uri,idx['versionCode'],idx['3'],TYPE_INT_DEC,3),(android_uri,idx['versionName'],idx['3.0'],TYPE_STRING,idx['3.0'])],line)); line+=1
    chunks.append(start_element(idx['uses-sdk'],[(android_uri,idx['targetSdkVersion'],idx['28'],TYPE_INT_DEC,28)],line)); line+=1
    chunks.append(end_element(idx['uses-sdk'],line)); line+=1
    chunks.append(start_element(idx['uses-permission'],[(android_uri,idx['name'],idx['android.permission.INTERNET'],TYPE_STRING,idx['android.permission.INTERNET'])],line)); line+=1
    chunks.append(end_element(idx['uses-permission'],line)); line+=1
    chunks.append(start_element(idx['application'],[(android_uri,idx['label'],idx['背词速度计'],TYPE_STRING,idx['背词速度计'])],line)); line+=1
    chunks.append(start_element(idx['activity'],[(android_uri,idx['name'],idx['.MainActivity'],TYPE_STRING,idx['.MainActivity'])],line)); line+=1
    chunks.append(start_element(idx['intent-filter'],[],line)); line+=1
    chunks.append(start_element(idx['action'],[(android_uri,idx['name'],idx['android.intent.action.MAIN'],TYPE_STRING,idx['android.intent.action.MAIN'])],line)); line+=1
    chunks.append(end_element(idx['action'],line)); line+=1
    chunks.append(start_element(idx['category'],[(android_uri,idx['name'],idx['android.intent.category.LAUNCHER'],TYPE_STRING,idx['android.intent.category.LAUNCHER'])],line)); line+=1
    chunks.append(end_element(idx['category'],line)); line+=1
    chunks.append(end_element(idx['intent-filter'],line)); line+=1
    chunks.append(end_element(idx['activity'],line)); line+=1
    chunks.append(end_element(idx['application'],line)); line+=1
    chunks.append(end_element(idx['manifest'],line)); line+=1
    chunks.append(ns_chunk(RES_XML_END_NAMESPACE_TYPE,idx['android'],android_uri,line)); line+=1
    body=string_pool(strings)+resmap+b''.join(chunks)
    return struct.pack('<HHI',RES_XML_TYPE,8,8+len(body))+body

# ---------------- DEX builder ----------------

def uleb(n):
    out=bytearray()
    while True:
        b=n & 0x7f; n >>= 7
        if n: out.append(b|0x80)
        else:
            out.append(b); return bytes(out)

def mutf8_ascii(s):
    # All DEX strings are intentionally ASCII.
    b=s.encode('ascii')
    return uleb(len(s))+b+b'\x00'

def align(buf,n=4):
    while len(buf)%n: buf.append(0)

def insn(*units):
    return b''.join(struct.pack('<H',x & 0xffff) for x in units)

def fmt35c(op, regs, method_idx):
    # regs list length <= 5: C,D,E,F,G
    regs=list(regs); A=len(regs)
    padded=regs+[0]*(5-len(regs))
    C,D,E,F,G=padded[:5]
    first=op | (G<<8) | (A<<12)
    third=C | (D<<4) | (E<<8) | (F<<12)
    return insn(first,method_idx,third)

def fmt3rc(op,count,method_idx,start_reg):
    return insn(op | (count<<8),method_idx,start_reg)

def code_item(registers,ins,outs,bytecode):
    assert len(bytecode)%2==0
    return struct.pack('<HHHHII',registers,ins,outs,0,0,len(bytecode)//2)+bytecode

def make_html():
    # ASCII-only HTML; Chinese UI is encoded as numeric entities / JS unicode escapes.
    return r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#0d0f13;color:#f5f7fb;font-family:system-ui,-apple-system,sans-serif}main{max-width:820px;margin:auto;padding:18px}.card{background:#171a21;border:1px solid #2a2f3a;border-radius:22px;padding:18px;margin:12px 0}.headline{display:grid;grid-template-columns:1fr 1fr;gap:12px}.metric{background:#11141a;border:1px solid #2a2f3a;border-radius:18px;padding:16px;min-width:0}.metric .k{color:#9aa4b2;font-size:14px}.metric .v{font-size:56px;font-weight:850;letter-spacing:-2px;line-height:1.05;margin:10px 0 3px;white-space:nowrap}.metric .u{color:#9aa4b2;font-size:14px}.metric.daily{border-color:#40547c}.muted{color:#9aa4b2;font-size:14px;line-height:1.6}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:12px}.stat{background:#11141a;border:1px solid #2a2f3a;border-radius:14px;padding:14px;min-width:0}.stat b{display:block;font-size:22px;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}input{width:100%;background:#10131a;color:#fff;border:1px solid #303744;border-radius:12px;padding:13px;font-size:16px;margin-top:7px}button{min-height:48px;border:0;border-radius:12px;font-size:16px;font-weight:750;padding:0 15px}.row{display:flex;gap:10px;margin-top:14px;flex-wrap:wrap}.row button{flex:1;min-width:120px}.primary{background:#7aa2ff;color:#07101f}.secondary{background:#282e3a;color:#fff}.danger{background:#492328;color:#ffd9dd}.status{margin-top:12px;background:#10131a;border-radius:10px;padding:11px;color:#9aa4b2;font-size:14px;line-height:1.55}.ok{color:#53d18b}.err{color:#ff8585}label{display:block;color:#aab3c0;font-size:14px;margin-top:5px}.note{margin-top:10px;border-left:3px solid #40547c;padding-left:10px}@media(max-width:620px){.headline{grid-template-columns:1fr}.metric .v{font-size:50px}.stats{grid-template-columns:1fr 1fr}}@media(max-width:380px){.metric .v{font-size:44px}}
</style></head><body><main><div class="muted">&#32972;&#35789;&#36895;&#24230;&#35745; &middot; &#22696;&#22696;&#23398;&#20064;&#25968;&#25454;&#33258;&#21160;&#21047;&#26032;</div><section class="card"><div class="headline"><div class="metric"><div class="k">&#26412;&#36718;&#24179;&#22343;</div><div id="sessionSpeed" class="v">0.00</div><div class="u">&#35789; / &#20998;&#38047;</div></div><div class="metric daily"><div class="k">&#20170;&#26085;&#24179;&#22343;</div><div id="daySpeed" class="v">0.00</div><div class="u">&#35789; / &#20998;&#38047;</div></div></div><div class="stats"><div class="stat"><span class="muted">&#26412;&#36718;&#26032;&#22686;</span><b id="sessionDelta">0</b></div><div class="stat"><span class="muted">&#26412;&#36718;&#29992;&#26102;</span><b id="sessionTime">00:00</b></div><div class="stat"><span class="muted">&#20170;&#26085;&#24050;&#32972;</span><b id="dayFinished">--</b></div><div class="stat"><span class="muted">&#20170;&#26085;&#23398;&#20064;&#26102;&#38271;</span><b id="dayTime">--</b></div></div><div class="muted note">&#20170;&#26085;&#24179;&#22343; = &#20170;&#26085;&#24050;&#23436;&#25104;&#35789;&#25968; &divide; &#22696;&#22696;&#35760;&#24405;&#30340;&#20170;&#26085;&#23398;&#20064;&#26102;&#38271;&#12290;&#19981;&#26159;&#20174;&#20940;&#28857;&#24320;&#22987;&#35745;&#26102;&#12290;</div></section><section class="card"><label>MaiMemo API Token</label><input id="token" type="password" autocomplete="off" placeholder="&#31896;&#36148; Token&#65292;&#19981;&#35201;&#24102; Bearer"><div class="row"><button id="test" class="secondary">&#27979;&#35797;&#36830;&#25509;</button><button id="start" class="primary">&#24320;&#22987;&#35745;&#36895;</button><button id="stop" class="danger">&#20572;&#27490;</button></div><div id="status" class="status">&#23578;&#26410;&#36830;&#25509;&#12290;</div><div class="muted" style="margin-top:10px">Token &#21482;&#20445;&#23384;&#22312;&#26412;&#26426;&#12290;&#24314;&#35758;&#22312;&#22696;&#22696;&#20013;&#24320;&#21551;&#23398;&#20064;&#25968;&#25454;&#33258;&#21160;&#21516;&#27493;&#12290;&#24320;&#22987;&#21518;&#27599; 10 &#31186;&#21047;&#26032;&#19968;&#27425;&#12290;</div></section></main><script>
(()=>{const $=id=>document.getElementById(id),tok=$('token'),ss=$('sessionSpeed'),ds=$('daySpeed'),sd=$('sessionDelta'),stme=$('sessionTime'),df=$('dayFinished'),dt=$('dayTime'),msgbox=$('status');let baseFinished=null,current=null,t0=null,poll=null,clock=null;tok.value=localStorage.getItem('mm_tok')||'';function msg(s,c=''){msgbox.textContent=s;msgbox.className='status '+c}function fmtShort(ms){let s=Math.max(0,Math.floor(ms/1000)),m=Math.floor(s/60),h=Math.floor(m/60);m=m%60;if(h>0)return h+':'+String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0');return String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}function fmtDay(ms){if(!Number.isFinite(ms)||ms<0)return '--';let totalSec=Math.floor(ms/1000),h=Math.floor(totalSec/3600),m=Math.floor((totalSec%3600)/60),s=totalSec%60;if(h>0)return h+'h '+m+'m';if(m>0)return m+'m '+s+'s';return s+'s'}function parseProgress(j){let q=[j],seen=new Set(),found=null;for(let depth=0;depth<5&&q.length;depth++){let nq=[];for(const x of q){if(!x||typeof x!=='object'||seen.has(x))continue;seen.add(x);let f=Number(x.finished),tm=Number(x.study_time);if(Number.isFinite(f)&&Number.isFinite(tm)){found=x;break}for(const k of ['data','progress','result'])if(x[k]&&typeof x[k]==='object')nq.push(x[k])}if(found)break;q=nq}if(!found)throw new Error('Cannot find finished/study_time in API response');let f=Number(found.finished),t=Number(found.total),tm=Number(found.study_time);return{finished:f,total:Number.isFinite(t)?t:null,studyTime:tm}}async function requestProgress(path){let t=tok.value.trim();let r=await fetch(path,{method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json','Authorization':'Bearer '+t},body:'{}',cache:'no-store'}),tx=await r.text(),j;try{j=JSON.parse(tx)}catch(e){throw new Error('HTTP '+r.status+' returned non-JSON')}if(!r.ok){let e=new Error('HTTP '+r.status);e.status=r.status;throw e}if(j&&j.success===false)throw new Error('API request unsuccessful');if(j&&Array.isArray(j.errors)&&j.errors.length)throw new Error('API returned an error');return parseProgress(j)}async function getProgress(){let t=tok.value.trim();if(!t)throw new Error('Please enter Token');localStorage.setItem('mm_tok',t);try{return await requestProgress('/open/api/v1/study/get_study_progress')}catch(e){if(e&&e.status&&![404,405].includes(e.status))throw e;return await requestProgress('/open/api/v1/memo/study/get_study_progress')}}function draw(){if(current){df.textContent=String(current.finished);dt.textContent=fmtDay(current.studyTime);let mins=current.studyTime/60000;ds.textContent=mins>0?(current.finished/mins).toFixed(2):'0.00'}if(t0&&baseFinished!=null){let ms=Date.now()-t0,d=Math.max(0,(current?current.finished:baseFinished)-baseFinished);sd.textContent=String(d);stme.textContent=fmtShort(ms);ss.textContent=ms>0?(d/(ms/60000)).toFixed(2):'0.00'}}async function update(){try{current=await getProgress();draw();msg('\u5df2\u8fde\u63a5 \u00b7 \u6b63\u5728\u81ea\u52a8\u5237\u65b0\u3002\u4eca\u65e5 '+current.finished+' \u8bcd\uff0c\u5b66\u4e60 '+fmtDay(current.studyTime)+'\u3002','ok')}catch(e){msg((e.message||String(e))+'\u3002\u8bf7\u68c0\u67e5 Token\u3001\u7f51\u7edc\u548c\u58a8\u58a8\u5b66\u4e60\u6570\u636e\u81ea\u52a8\u540c\u6b65\u3002','err')}}$('test').addEventListener('click',async()=>{try{msg('\u6b63\u5728\u6d4b\u8bd5...');current=await getProgress();draw();let mins=current.studyTime/60000,avg=mins>0?(current.finished/mins).toFixed(2):'0.00';msg('\u8fde\u63a5\u6210\u529f\u3002\u4eca\u65e5 '+current.finished+' \u8bcd / '+fmtDay(current.studyTime)+'\uff0c\u5e73\u5747 '+avg+' \u8bcd/\u5206\u949f\u3002','ok')}catch(e){msg((e.message||String(e))+'\u3002','err')}});$('start').addEventListener('click',async()=>{if(poll)clearInterval(poll);if(clock)clearInterval(clock);try{msg('\u6b63\u5728\u8bfb\u53d6\u8d77\u59cb\u8fdb\u5ea6...');current=await getProgress();baseFinished=current.finished;t0=Date.now();draw();msg('\u5df2\u5f00\u59cb\u3002\u672c\u8f6e\u8d77\u59cb '+baseFinished+' \u8bcd\uff1b\u4eca\u65e5\u901f\u5ea6\u540c\u6b65\u663e\u793a\u3002','ok');poll=setInterval(update,10000);clock=setInterval(draw,1000)}catch(e){msg((e.message||String(e))+'\u3002','err')}});$('stop').addEventListener('click',()=>{if(poll)clearInterval(poll);if(clock)clearInterval(clock);poll=clock=null;msg('\u5df2\u505c\u6b62\u81ea\u52a8\u5237\u65b0\uff0c\u5f53\u524d\u6570\u636e\u4fdd\u7559\u3002')});})();
</script></body></html>'''

def build_dex(html):
    # descriptors/types
    strings=set([
        '<init>','onCreate','getSettings','setJavaScriptEnabled','setDomStorageEnabled','loadDataWithBaseURL','setContentView',
        'Landroid/app/Activity;','Landroid/content/Context;','Landroid/os/Bundle;','Landroid/view/View;',
        'Landroid/webkit/WebSettings;','Landroid/webkit/WebView;',MAIN_DESC,'Ljava/lang/String;','V','Z',
        'VL','L','VZ','VLLLLL','https://open.maimemo.com/',html,'text/html','utf-8'
    ])
    # Sort strings lexicographically (ASCII == UTF-16 ordering here)
    strings=sorted(strings)
    sidx={s:i for i,s in enumerate(strings)}

    type_descs=['Landroid/app/Activity;','Landroid/content/Context;','Landroid/os/Bundle;','Landroid/view/View;','Landroid/webkit/WebSettings;','Landroid/webkit/WebView;',MAIN_DESC,'Ljava/lang/String;','V','Z']
    type_descs=sorted(type_descs,key=lambda s:sidx[s])
    tidx={s:i for i,s in enumerate(type_descs)}

    protos=[
        ('V','V',()),
        ('VL','V',('Landroid/os/Bundle;',)),
        ('VL','V',('Landroid/content/Context;',)),
        ('L','Landroid/webkit/WebSettings;',()),
        ('VZ','V',('Z',)),
        ('VLLLLL','V',('Ljava/lang/String;',)*5),
        ('VL','V',('Landroid/view/View;',)),
    ]
    # dedupe preserving tuples, then sort by return type idx then param type idx list (spec-ish)
    uniq=[]
    for p in protos:
        if p not in uniq: uniq.append(p)
    def pkey(p): return (tidx[p[1]], tuple(tidx[x] for x in p[2]), sidx[p[0]])
    protos=sorted(uniq,key=pkey)
    pidx={p:i for i,p in enumerate(protos)}

    def P(shorty,ret,params): return pidx[(shorty,ret,tuple(params))]
    methods=[
        ('Landroid/app/Activity;','<init>',P('V','V',())),
        ('Landroid/app/Activity;','onCreate',P('VL','V',('Landroid/os/Bundle;',))),
        ('Landroid/app/Activity;','setContentView',P('VL','V',('Landroid/view/View;',))),
        ('Landroid/webkit/WebSettings;','setJavaScriptEnabled',P('VZ','V',('Z',))),
        ('Landroid/webkit/WebSettings;','setDomStorageEnabled',P('VZ','V',('Z',))),
        ('Landroid/webkit/WebView;','<init>',P('VL','V',('Landroid/content/Context;',))),
        ('Landroid/webkit/WebView;','getSettings',P('L','Landroid/webkit/WebSettings;',())),
        ('Landroid/webkit/WebView;','loadDataWithBaseURL',P('VLLLLL','V',('Ljava/lang/String;',)*5)),
        (MAIN_DESC,'<init>',P('V','V',())),
        (MAIN_DESC,'onCreate',P('VL','V',('Landroid/os/Bundle;',))),
    ]
    methods=sorted(methods,key=lambda m:(tidx[m[0]],sidx[m[1]],m[2]))
    midx={m:i for i,m in enumerate(methods)}
    def M(cls,name,proto): return midx[(cls,name,proto)]

    # Fixed sections sizes/offsets
    header_size=0x70
    string_ids_off=header_size
    string_ids_size=len(strings)
    type_ids_off=string_ids_off+4*string_ids_size
    type_ids_size=len(type_descs)
    proto_ids_off=type_ids_off+4*type_ids_size
    proto_ids_size=len(protos)
    method_ids_off=proto_ids_off+12*proto_ids_size
    method_ids_size=len(methods)
    class_defs_off=method_ids_off+8*method_ids_size
    class_defs_size=1
    data_off=class_defs_off+32

    data=bytearray()
    # string data
    string_data_offs=[]
    for s in strings:
        string_data_offs.append(data_off+len(data))
        data += mutf8_ascii(s)
    align(data,4)

    # type lists for proto params
    param_off={}
    for p in protos:
        params=p[2]
        if not params: continue
        if params in param_off: continue
        align(data,4)
        off=data_off+len(data); param_off[params]=off
        data += struct.pack('<I',len(params))
        for t in params: data += struct.pack('<H',tidx[t])
        if len(params)%2: data += b'\x00\x00'

    align(data,4)
    # code items
    code_offsets={}
    # Constructor
    ctor_bc=bytearray()
    ctor_bc += fmt35c(0x70,[0],M('Landroid/app/Activity;','<init>',P('V','V',())))
    ctor_bc += insn(0x000e)
    code_offsets['ctor']=data_off+len(data)
    data += code_item(1,1,1,bytes(ctor_bc)); align(data,4)

    # onCreate, registers 8: v0-v5,p0=v6,p1=v7
    bc=bytearray()
    bc += fmt35c(0x6f,[6,7],M('Landroid/app/Activity;','onCreate',P('VL','V',('Landroid/os/Bundle;',))))
    bc += insn(0x0022,tidx['Landroid/webkit/WebView;'])  # new-instance v0
    bc += fmt35c(0x70,[0,6],M('Landroid/webkit/WebView;','<init>',P('VL','V',('Landroid/content/Context;',))))
    bc += fmt35c(0x6e,[0],M('Landroid/webkit/WebView;','getSettings',P('L','Landroid/webkit/WebSettings;',())))
    bc += insn(0x010c)  # move-result-object v1
    bc += insn(0x1212)  # const/4 v2, #1
    bc += fmt35c(0x6e,[1,2],M('Landroid/webkit/WebSettings;','setJavaScriptEnabled',P('VZ','V',('Z',))))
    bc += fmt35c(0x6e,[1,2],M('Landroid/webkit/WebSettings;','setDomStorageEnabled',P('VZ','V',('Z',))))
    bc += insn(0x011a,sidx['https://open.maimemo.com/'])
    bc += insn(0x021a,sidx[html])
    bc += insn(0x031a,sidx['text/html'])
    bc += insn(0x041a,sidx['utf-8'])
    bc += insn(0x0512)  # const/4 v5, #0 (null)
    bc += fmt3rc(0x74,6,M('Landroid/webkit/WebView;','loadDataWithBaseURL',P('VLLLLL','V',('Ljava/lang/String;',)*5)),0)
    bc += fmt35c(0x6e,[6,0],M('Landroid/app/Activity;','setContentView',P('VL','V',('Landroid/view/View;',))))
    bc += insn(0x000e)
    code_offsets['onCreate']=data_off+len(data)
    data += code_item(8,2,6,bytes(bc)); align(data,4)

    # class_data item
    class_data_off=data_off+len(data)
    ctor_mid=M(MAIN_DESC,'<init>',P('V','V',()))
    on_mid=M(MAIN_DESC,'onCreate',P('VL','V',('Landroid/os/Bundle;',)))
    cdata=bytearray()
    cdata+=uleb(0)+uleb(0)+uleb(1)+uleb(1)
    cdata+=uleb(ctor_mid)+uleb(0x10001)+uleb(code_offsets['ctor'])
    cdata+=uleb(on_mid)+uleb(0x0004)+uleb(code_offsets['onCreate'])
    data += cdata
    align(data,4)

    # map list
    map_off=data_off+len(data)
    # We'll include map entries sorted by offset.
    entries=[]
    entries.append((0x0000,1,0))
    entries.append((0x0001,string_ids_size,string_ids_off))
    entries.append((0x0002,type_ids_size,type_ids_off))
    entries.append((0x0003,proto_ids_size,proto_ids_off))
    entries.append((0x0005,method_ids_size,method_ids_off))
    entries.append((0x0006,1,class_defs_off))
    entries.append((0x2002,string_ids_size,min(string_data_offs)))
    if param_off: entries.append((0x1001,len(param_off),min(param_off.values())))
    entries.append((0x2001,2,min(code_offsets.values())))
    entries.append((0x2000,1,class_data_off))
    entries.append((0x1000,1,map_off))
    entries=sorted(entries,key=lambda e:e[2])
    data += struct.pack('<I',len(entries))
    for typ,size,off in entries:
        data += struct.pack('<HHII',typ,0,size,off)

    file_size=data_off+len(data)
    data_size=len(data)

    out=bytearray(b'\x00'*header_size)
    # id sections
    for off in string_data_offs: out += struct.pack('<I',off)
    for td in type_descs: out += struct.pack('<I',sidx[td])
    for p in protos:
        shorty,ret,params=p
        out += struct.pack('<III',sidx[shorty],tidx[ret],param_off.get(params,0))
    for cls,name,pi in methods:
        out += struct.pack('<HHI',tidx[cls],pi,sidx[name])
    # class def
    out += struct.pack('<IIIIIIII',tidx[MAIN_DESC],0x21,tidx['Landroid/app/Activity;'],0,NO_INDEX,0,class_data_off,0)
    assert len(out)==data_off,(len(out),data_off)
    out += data
    assert len(out)==file_size

    # Header (signature/checksum later)
    out[0:8]=b'dex\n035\x00'
    # checksum 8:12, signature12:32
    struct.pack_into('<I',out,32,file_size)
    struct.pack_into('<I',out,36,0x70)
    struct.pack_into('<I',out,40,0x12345678)
    struct.pack_into('<I',out,44,0); struct.pack_into('<I',out,48,0)
    struct.pack_into('<I',out,52,map_off)
    struct.pack_into('<II',out,56,string_ids_size,string_ids_off)
    struct.pack_into('<II',out,64,type_ids_size,type_ids_off)
    struct.pack_into('<II',out,72,proto_ids_size,proto_ids_off)
    struct.pack_into('<II',out,80,0,0) # field ids
    struct.pack_into('<II',out,88,method_ids_size,method_ids_off)
    struct.pack_into('<II',out,96,1,class_defs_off)
    struct.pack_into('<II',out,104,data_size,data_off)
    sig=hashlib.sha1(out[32:]).digest(); out[12:32]=sig
    chk=zlib.adler32(out[12:]) & 0xffffffff; struct.pack_into('<I',out,8,chk)
    return bytes(out)


def build_unsigned():
    manifest=build_manifest()
    html=make_html()
    assert all(ord(c)<128 for c in html)
    dex=build_dex(html)
    p=OUTDIR/'wordmeter-unsigned.apk'
    with zipfile.ZipFile(p,'w') as z:
        z.writestr('AndroidManifest.xml',manifest,compress_type=zipfile.ZIP_DEFLATED)
        z.writestr('classes.dex',dex,compress_type=zipfile.ZIP_DEFLATED)
    return p,manifest,dex,html

if __name__=='__main__':
    p,manifest,dex,html=build_unsigned()
    print('unsigned',p,'size',p.stat().st_size,'manifest',len(manifest),'dex',len(dex),'html',len(html))
